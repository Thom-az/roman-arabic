function convertToRoman() {
    const arabicInput = document.getElementById('arabicInput').value;
    const result = arabicToRoman(parseInt(arabicInput));
    document.getElementById('result').innerText = `Romano: ${result}`;
  }
  
  function convertToArabic() {
    const romanInput = document.getElementById('romanInput').value.toUpperCase();
    const result = romanToArabic(romanInput);
    document.getElementById('result').innerText = `Arábico: ${result}`;
  }
  
  function arabicToRoman(num) {
    const romanNumeralMap = [
      { value: 1000, numeral: 'M' },
      { value: 900, numeral: 'CM' },
      { value: 500, numeral: 'D' },
      { value: 400, numeral: 'CD' },
      { value: 100, numeral: 'C' },
      { value: 90, numeral: 'XC' },
      { value: 50, numeral: 'L' },
      { value: 40, numeral: 'XL' },
      { value: 10, numeral: 'X' },
      { value: 9, numeral: 'IX' },
      { value: 5, numeral: 'V' },
      { value: 4, numeral: 'IV' },
      { value: 1, numeral: 'I' }
    ];
    
    let roman = '';
    for (let i = 0; i < romanNumeralMap.length; i++) {
      while (num >= romanNumeralMap[i].value) {
        roman += romanNumeralMap[i].numeral;
        num -= romanNumeralMap[i].value;
      }
    }
    return roman;
  }
  
  function romanToArabic(roman) {
    const romanNumeralMap = {
      'I': 1,
      'V': 5,
      'X': 10,
      'L': 50,
      'C': 100,
      'D': 500,
      'M': 1000
    };
    
    let num = 0;
    for (let i = 0; i < roman.length; i++) {
      const current = romanNumeralMap[roman[i]];
      const next = romanNumeralMap[roman[i + 1]];
      
      if (next && current < next) {
        num -= current;
      } else {
        num += current;
      }
    }
    return num;
  }
  